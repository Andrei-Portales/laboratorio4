
public class Revista extends Documentacion{

	private int ano;
	private int numero;
	
	
	
	public Revista(){
		super();
		ano = 0;
		numero = 0;
	}
	
	public Revista(int ano,int numero,int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		super(numIdentificacion,titulo,materia,cantidadEjemplares,estado);
		this.ano = ano;
		this.numero = numero;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		return "Revista [ano=" + ano + ", numero=" + numero + "]";
	}
	
	
	
	
}
