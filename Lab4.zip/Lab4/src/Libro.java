
public class Libro extends Documentacion{

	private String autor;
	private String editorial;
	
	
	public Libro() {
		super();
		autor = "";
		editorial = "";
		
	}
	
	public Libro(String autor, String editorial,int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		super(numIdentificacion,titulo,materia,cantidadEjemplares,estado);
		this.autor = autor;
		this.editorial = editorial;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	@Override
	public String toString() {
		return "Libro [autor=" + autor + ", editorial=" + editorial + "]";
	}
	
	
	
	
}
