
public class Articulo extends Documentacion{

	
	private String arbitro;
	private String autor;
	
	
	public Articulo() {
		super();
		arbitro = "";
		autor = "";
	}


	public Articulo(String arbitro, String autor, int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		super(numIdentificacion,titulo,materia,cantidadEjemplares,estado);
		this.arbitro = arbitro;
		this.autor = autor;
	}


	/**
	 * @return the arbitro
	 */
	public String getArbitro() {
		return arbitro;
	}


	/**
	 * @param arbitro the arbitro to set
	 */
	public void setArbitro(String arbitro) {
		this.arbitro = arbitro;
	}


	/**
	 * @return the autor
	 */
	public String getAutor() {
		return autor;
	}


	/**
	 * @param autor the autor to set
	 */
	public void setAutor(String autor) {
		this.autor = autor;
	}


	@Override
	public String toString() {
		return "Articulo [arbitro=" + arbitro + ", autor=" + autor + "]";
	}



	
	
}
