import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import java.awt.SystemColor;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.ArrayList;

import javax.swing.AbstractListModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;

public class PrincipalGUI {
	Biblioteca biblioteca = new Biblioteca();
	private JFrame frame;
	private JButton btnClientes,btnDocumentacion,btnSalir,btnPrestamos,btnEstadisticas,btnRegresarClientes,btnCrear,btnEliminar,btnRegresarPrestamos,
	btnMostrar ;
	private JPanel Clientes,Prestamos,Documentacion,Estadisticas,Biblioteca ;
	private JLabel lblCrearCliente;
	private JTextField txtIdentificacion;
	private JTextField txtNombre;
	private JTextField txtDireccion;
	private JSeparator separator_1;
	private JSeparator separator_2;
	private JLabel lblEliminarCliente;
	private JComboBox cbClientes,cbMostrarClientes;
	private JLabel lblCliente;
	private JLabel lblMostarClientes;
	private JLabel label;
	private JButton btnMostrarClientes,btnPrestar;
	private JButton btnBorrar;
	private JList listClientes;
	private JScrollPane scrollPane;
	private JLabel lblDocumentacion;
	private JSeparator separator_5;
	private JButton btnRegresarDocumentacion;
	private JLabel lblCrearDocumento,lblPestamosActivos;
	private JComboBox cbTipo,cbClientesPrestamos,cbClientesPrestamo1;
	private JLabel lblTipo,lblPrestamosInactivos;
	private JLabel lblNumeroDeIdentificacion;
	private JTextField txtIdentificacion1;
	private JLabel lblTitulo;
	private JLabel lblMateria;
	private JLabel lblCantidadDeEjemplares;
	private JLabel lblEstado;
	private JLabel lblEditorial;
	private JTextField txtTitulo;
	private JLabel lblAno;
	private JLabel lblNumero;
	private JLabel lblArbitro;
	private JTextField txtMateria;
	private JTextField txtCantEjemplares;
	private JTextField txtAutor;
	private JTextField txtEditorial;
	private JTextField txtNumero;
	private JTextField txtArbitro;
	private JButton btnAgregar,btnConsultarCliente;
	private JComboBox cbAnos;
	private JLabel lblseActivaranLas;
	private JSeparator separator_6;
	private JLabel lblConsultarInformacion;
	private JComboBox cbConsultaDocumento;
	private JButton btnMostrarDocumento,btnMostrarPrestamos1;
	private JList listDocumentos,listMostrarPrestamos;
	private JScrollPane scrollPane_1;
	private JLabel lblInformacionDeDocumento,lblArticulosPrestamos;
	private JList listInformacionDocumento,listIformacionPrestamos;
	private JScrollPane scrollPane_2;
	private JButton btnBorrarDocumentos;
	private JLabel lblCrearPrestamo;
	private JLabel label_1;
	private JComboBox cbTipoPrestamo;
	private JButton btnMostrarPrestamos;
	private JLabel lblCliente_1,lblLibrosPrestamos;
	private JComboBox cbClientesPrestamo;
	private JLabel lblLibros;
	private JLabel lblRevistas;
	private JLabel lblArticulos;
	private JLabel lblCantlibros;
	private JLabel lblCantRevistas;
	private JLabel lblCantArticulos;
	private JLabel lblFechaDePrestamos;
	private JLabel lblFechaDeDevolucion;
	private JComboBox diaP,cbClientesPrestamosConsultar;
	private JComboBox mesP,cbTipoPrestamo1;
	private JComboBox anoP;
	private JLabel lblDia;
	private JLabel lblMes;
	private JLabel lblAo;
	private JComboBox diaD,cbClientesPrestamos1;
	private JLabel label_2;
	private JComboBox mesD;
	private JLabel label_3,lblRevistasPrestamos;
	private JLabel label_4;
	private JComboBox anoD;
	private JLabel lblModificarPrestamo;
	private JComboBox cbCambiar;
	private JLabel lblCambiar;
	private JButton btnAbilitar;
	private JLabel lblFechaEntrega;
	private JComboBox diaPP;
	private JLabel label_9;
	private JComboBox mesPP;
	private JLabel label_10;
	private JComboBox anoPP;
	private JLabel label_11;
	private JLabel lblEntrega;
	private JComboBox cbEntregaCambio;
	private JButton btnCambiar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrincipalGUI window = new PrincipalGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrincipalGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize() {
		
		MyListener oyente = new MyListener();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1146, 739);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		
		Biblioteca = new JPanel();
		Biblioteca.setBackground(Color.WHITE);
		frame.getContentPane().add(Biblioteca, "name_17826120643666");
		Biblioteca.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(281, 152, 557, 380);
		Biblioteca.add(panel);
		panel.setLayout(null);
		
		btnClientes = new JButton("Clientes");
		btnClientes.setBackground(Color.WHITE);
		btnClientes.setBounds(57, 89, 145, 37);
		panel.add(btnClientes);
		btnClientes.addActionListener(oyente);
		
		btnDocumentacion = new JButton("Documentacion");
		btnDocumentacion.setBackground(Color.WHITE);
		btnDocumentacion.setBounds(57, 182, 145, 37);
		panel.add(btnDocumentacion);
		btnDocumentacion.addActionListener(oyente);
		
		btnSalir = new JButton("Guardar y Salir");
		btnSalir.setBackground(Color.WHITE);
		btnSalir.setBounds(201, 267, 145, 37);
		panel.add(btnSalir);
		btnSalir.addActionListener(oyente);
		
		btnPrestamos = new JButton("Prestamos");
		btnPrestamos.setBackground(Color.WHITE);
		btnPrestamos.setBounds(342, 89, 145, 37);
		panel.add(btnPrestamos);
		btnPrestamos.addActionListener(oyente);
		
		btnEstadisticas = new JButton("Estadisticas");
		btnEstadisticas.setBackground(Color.WHITE);
		btnEstadisticas.setBounds(342, 182, 145, 37);
		panel.add(btnEstadisticas);
		btnEstadisticas.addActionListener(oyente);
		
		JLabel lblElijaLaOpcion = new JLabel("Elija la opcion que desee");
		lblElijaLaOpcion.setBounds(103, 6, 357, 59);
		panel.add(lblElijaLaOpcion);
		lblElijaLaOpcion.setFont(new Font("Arial", Font.PLAIN, 30));
		
		JLabel lblNewLabel = new JLabel("Bienvenido");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 60));
		lblNewLabel.setBounds(381, 28, 371, 92);
		Biblioteca.add(lblNewLabel);
		
		Clientes = new JPanel();
		frame.getContentPane().add(Clientes, "name_17020723850707");
		Clientes.setBackground(Color.WHITE);
		Clientes.setLayout(null);
		
		btnRegresarClientes = new JButton("Regresar");
		btnRegresarClientes.setBackground(Color.ORANGE);
		btnRegresarClientes.setBounds(6, 19, 117, 29);
		Clientes.add(btnRegresarClientes);
		
		JLabel lblClientes = new JLabel("Clientes");
		lblClientes.setFont(new Font("Arial", Font.PLAIN, 30));
		lblClientes.setBounds(488, 2, 126, 51);
		Clientes.add(lblClientes);
		
		lblCrearCliente = new JLabel("Crear Cliente");
		lblCrearCliente.setFont(new Font("Arial", Font.PLAIN, 20));
		lblCrearCliente.setBounds(16, 69, 126, 44);
		Clientes.add(lblCrearCliente);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(6, 45, 1133, 12);
		Clientes.add(separator);
		
		JLabel lblIdentificacion = new JLabel("No.identificacion: ");
		lblIdentificacion.setBounds(6, 125, 128, 16);
		Clientes.add(lblIdentificacion);
		
		txtIdentificacion = new JTextField();
		txtIdentificacion.setBounds(134, 120, 213, 26);
		Clientes.add(txtIdentificacion);
		txtIdentificacion.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(59, 159, 64, 16);
		Clientes.add(lblNombre);
		
		txtNombre = new JTextField();
		txtNombre.setColumns(10);
		txtNombre.setBounds(134, 154, 213, 26);
		Clientes.add(txtNombre);
		
		JLabel lblDireccion = new JLabel("Direccion:");
		lblDireccion.setBounds(51, 192, 72, 16);
		Clientes.add(lblDireccion);
		
		txtDireccion = new JTextField();
		txtDireccion.setColumns(10);
		txtDireccion.setBounds(134, 187, 213, 26);
		Clientes.add(txtDireccion);
		
		btnCrear = new JButton("Crear");
		btnCrear.setBackground(Color.CYAN);
		btnCrear.setBounds(370, 187, 117, 29);
		Clientes.add(btnCrear);
		btnCrear.addActionListener(oyente);
		
		separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(6, 228, 495, 12);
		Clientes.add(separator_1);
		
		separator_2 = new JSeparator();
		separator_2.setForeground(Color.BLACK);
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(499, 52, 13, 630);
		Clientes.add(separator_2);
		
		lblEliminarCliente = new JLabel("Eliminar Cliente");
		lblEliminarCliente.setFont(new Font("Arial", Font.PLAIN, 20));
		lblEliminarCliente.setBounds(16, 252, 161, 44);
		Clientes.add(lblEliminarCliente);
		
		cbClientes = new JComboBox();
		cbClientes.setBackground(Color.WHITE);
		cbClientes.setBounds(72, 308, 224, 29);
		Clientes.add(cbClientes);
		
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.setBackground(Color.CYAN);
		btnEliminar.setBounds(308, 308, 117, 29);
		Clientes.add(btnEliminar);
		btnEliminar.addActionListener(oyente);
		
		lblCliente = new JLabel("Cliente:");
		lblCliente.setBounds(26, 313, 55, 16);
		Clientes.add(lblCliente);
		
		lblMostarClientes = new JLabel("Mostar Clientes");
		lblMostarClientes.setFont(new Font("Arial", Font.PLAIN, 20));
		lblMostarClientes.setBounds(540, 65, 199, 44);
		Clientes.add(lblMostarClientes);
		
		label = new JLabel("Cliente:");
		label.setBounds(540, 133, 55, 16);
		Clientes.add(label);
		
		cbMostrarClientes = new JComboBox();
		cbMostrarClientes.setBackground(Color.WHITE);
		cbMostrarClientes.setBounds(592, 128, 258, 29);
		Clientes.add(cbMostrarClientes);
		
		btnMostrarClientes = new JButton("Mostrar");
		btnMostrarClientes.setBackground(Color.CYAN);
		btnMostrarClientes.setBounds(862, 128, 117, 29);
		Clientes.add(btnMostrarClientes);
		btnMostrarClientes.addActionListener(oyente);
		
		btnBorrar = new JButton("borrar");
		btnBorrar.setBackground(Color.CYAN);
		btnBorrar.setBounds(991, 128, 117, 29);
		Clientes.add(btnBorrar);
		btnBorrar.addActionListener(oyente);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(540, 192, 558, 159);
		Clientes.add(scrollPane);
		
		
		listClientes = new JList();
		listClientes.setFont(new Font("Arial", Font.PLAIN, 20));
		
		scrollPane.setViewportView(listClientes);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setForeground(Color.BLACK);
		separator_3.setBounds(6, 349, 495, 12);
		Clientes.add(separator_3);
		btnRegresarClientes.addActionListener(oyente);
		
		
		Prestamos = new JPanel();
		Prestamos.setBackground(Color.WHITE);
		frame.getContentPane().add(Prestamos, "name_17826133642201");
		Prestamos.setLayout(null);
		
		JLabel lblPrestamos = new JLabel("Prestamos");
		lblPrestamos.setFont(new Font("Arial", Font.PLAIN, 30));
		lblPrestamos.setBounds(472, 6, 163, 51);
		Prestamos.add(lblPrestamos);
		
		btnRegresarPrestamos = new JButton("Regresar");
		btnRegresarPrestamos.setBackground(Color.ORANGE);
		btnRegresarPrestamos.setBounds(6, 23, 117, 29);
		Prestamos.add(btnRegresarPrestamos);
		btnRegresarPrestamos.addActionListener(oyente);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setForeground(Color.BLACK);
		separator_4.setBounds(6, 49, 1133, 12);
		Prestamos.add(separator_4);
		
		lblCrearPrestamo = new JLabel("Crear Prestamo");
		lblCrearPrestamo.setFont(new Font("Arial", Font.PLAIN, 20));
		lblCrearPrestamo.setBounds(16, 64, 188, 44);
		Prestamos.add(lblCrearPrestamo);
		
		label_1 = new JLabel("Tipo:");
		label_1.setBounds(30, 192, 42, 16);
		Prestamos.add(label_1);
		
		cbTipoPrestamo = new JComboBox();
		cbTipoPrestamo.setModel(new DefaultComboBoxModel(new String[] {"Libro", "Revista", "Articulo"}));
		cbTipoPrestamo.setBounds(69, 184, 106, 35);
		Prestamos.add(cbTipoPrestamo);
		
		btnMostrarPrestamos = new JButton("Mostrar");
		btnMostrarPrestamos.setBackground(Color.CYAN);
		btnMostrarPrestamos.setBounds(244, 235, 117, 29);
		Prestamos.add(btnMostrarPrestamos);
		btnMostrarPrestamos.addActionListener(oyente);
		
		lblCliente_1 = new JLabel("Cliente:");
		lblCliente_1.setBounds(16, 141, 57, 16);
		Prestamos.add(lblCliente_1);
		
		cbClientesPrestamo = new JComboBox();
		cbClientesPrestamo.setBounds(70, 133, 157, 35);
		Prestamos.add(cbClientesPrestamo);
		
		cbClientesPrestamos = new JComboBox();
		cbClientesPrestamos.setBounds(79, 232, 163, 35);
		Prestamos.add(cbClientesPrestamos);
		
		JLabel lblNombre_1 = new JLabel("Nombre:");
		lblNombre_1.setBounds(6, 240, 65, 16);
		Prestamos.add(lblNombre_1);
		
		lblFechaDePrestamos = new JLabel("Fecha de prestamo:");
		lblFechaDePrestamos.setBounds(6, 309, 142, 16);
		Prestamos.add(lblFechaDePrestamos);
		
		lblFechaDeDevolucion = new JLabel("Fecha de Devolucion:");
		lblFechaDeDevolucion.setBounds(6, 380, 142, 16);
		Prestamos.add(lblFechaDeDevolucion);
		
		diaP = new JComboBox();
		diaP.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		diaP.setBounds(138, 305, 65, 27);
		Prestamos.add(diaP);
		
		mesP = new JComboBox();
		mesP.setModel(new DefaultComboBoxModel(new String[] {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"}));
		mesP.setBounds(208, 305, 96, 27);
		Prestamos.add(mesP);
		
		anoP = new JComboBox();
		anoP.setModel(new DefaultComboBoxModel(new String[] {"2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010"}));
		anoP.setBounds(304, 305, 82, 27);
		Prestamos.add(anoP);
		
		lblDia = new JLabel("Dia");
		lblDia.setBounds(153, 290, 31, 16);
		Prestamos.add(lblDia);
		
		lblMes = new JLabel("Mes");
		lblMes.setBounds(224, 290, 31, 16);
		Prestamos.add(lblMes);
		
		lblAo = new JLabel("Año");
		lblAo.setBounds(330, 290, 31, 16);
		Prestamos.add(lblAo);
		
		diaD = new JComboBox();
		diaD.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		diaD.setBounds(152, 378, 65, 27);
		Prestamos.add(diaD);
		
		label_2 = new JLabel("Dia");
		label_2.setBounds(167, 363, 31, 16);
		Prestamos.add(label_2);
		
		mesD = new JComboBox();
		mesD.setModel(new DefaultComboBoxModel(new String[] {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"}));
		mesD.setBounds(222, 378, 96, 27);
		Prestamos.add(mesD);
		
		label_3 = new JLabel("Mes");
		label_3.setBounds(238, 363, 31, 16);
		Prestamos.add(label_3);
		
		label_4 = new JLabel("Año");
		label_4.setBounds(344, 363, 31, 16);
		Prestamos.add(label_4);
		
		anoD = new JComboBox();
		anoD.setModel(new DefaultComboBoxModel(new String[] {"2019", "2020", "2021", "2022", "2023", "2024", "2025"}));
		anoD.setBounds(318, 378, 82, 27);
		Prestamos.add(anoD);
		
		btnPrestar = new JButton("Prestar");
		btnPrestar.setBackground(Color.CYAN);
		btnPrestar.setBounds(406, 375, 117, 29);
		Prestamos.add(btnPrestar);
		
		lblModificarPrestamo = new JLabel("Modificar Prestamo");
		lblModificarPrestamo.setFont(new Font("Arial", Font.PLAIN, 20));
		lblModificarPrestamo.setBounds(16, 417, 188, 44);
		Prestamos.add(lblModificarPrestamo);
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setForeground(Color.BLACK);
		separator_7.setBounds(6, 408, 534, 16);
		Prestamos.add(separator_7);
		
		JLabel label_5 = new JLabel("Cliente:");
		label_5.setBounds(16, 481, 57, 16);
		Prestamos.add(label_5);
		
		cbClientesPrestamo1 = new JComboBox();
		cbClientesPrestamo1.setBounds(70, 473, 157, 35);
		Prestamos.add(cbClientesPrestamo1);
		
		JLabel label_6 = new JLabel("Tipo:");
		label_6.setBounds(30, 517, 42, 16);
		Prestamos.add(label_6);
		
		cbTipoPrestamo1 = new JComboBox();
		cbTipoPrestamo1.setModel(new DefaultComboBoxModel(new String[] {"Libro", "Revista", "Articulo"}));
		cbTipoPrestamo1.setBounds(69, 509, 106, 35);
		Prestamos.add(cbTipoPrestamo1);
		
		btnMostrarPrestamos1 = new JButton("Mostrar");
		btnMostrarPrestamos1.setBackground(Color.CYAN);
		btnMostrarPrestamos1.setBounds(238, 548, 117, 29);
		Prestamos.add(btnMostrarPrestamos1);
		btnMostrarPrestamos1.addActionListener(oyente);
		
		JLabel label_7 = new JLabel("Nombre:");
		label_7.setBounds(16, 553, 65, 16);
		Prestamos.add(label_7);
		
		cbClientesPrestamos1 = new JComboBox();
		cbClientesPrestamos1.setBounds(79, 545, 163, 35);
		Prestamos.add(cbClientesPrestamos1);
		cbClientesPrestamos1.addActionListener(oyente);
		
		JSeparator separator_8 = new JSeparator();
		separator_8.setOrientation(SwingConstants.VERTICAL);
		separator_8.setForeground(Color.BLACK);
		separator_8.setBounds(539, 57, 12, 654);
		Prestamos.add(separator_8);
		
		JLabel lblConsultar = new JLabel("Consultar");
		lblConsultar.setFont(new Font("Arial", Font.PLAIN, 20));
		lblConsultar.setBounds(563, 69, 106, 44);
		Prestamos.add(lblConsultar);
		
		JLabel label_8 = new JLabel("Cliente:");
		label_8.setBounds(563, 130, 57, 16);
		Prestamos.add(label_8);
		
		cbClientesPrestamosConsultar = new JComboBox();
		cbClientesPrestamosConsultar.setBounds(617, 122, 157, 35);
		Prestamos.add(cbClientesPrestamosConsultar);
		
		btnConsultarCliente = new JButton("Mostrar");
		btnConsultarCliente.setBackground(Color.CYAN);
		btnConsultarCliente.setBounds(786, 125, 117, 29);
		Prestamos.add(btnConsultarCliente);
		btnConsultarCliente.addActionListener(oyente);
		
		JLabel lblPrestamosActivos = new JLabel("Prestamos activos:");
		lblPrestamosActivos.setBounds(573, 169, 129, 16);
		Prestamos.add(lblPrestamosActivos);
		
		lblPestamosActivos = new JLabel("");
		lblPestamosActivos.setBounds(706, 169, 129, 16);
		Prestamos.add(lblPestamosActivos);
		
		JLabel lbl_1243 = new JLabel("Prestamos inactivos:");
		lbl_1243.setBounds(573, 197, 142, 16);
		Prestamos.add(lbl_1243);
		
		lblPrestamosInactivos = new JLabel("");
		lblPrestamosInactivos.setBounds(716, 197, 142, 16);
		Prestamos.add(lblPrestamosInactivos);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(573, 225, 543, 186);
		Prestamos.add(scrollPane_3);
		
		listMostrarPrestamos = new JList();
		listMostrarPrestamos.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				String split = (String) listMostrarPrestamos.getSelectedValue();
				
				String[] sep = split.split(" : ");
				String[] sep1 = sep[1].split(" - ");
				
				String[] values = biblioteca.getInformacionPrestamo(cbClientesPrestamosConsultar.getSelectedItem().toString(), sep[0].toString(), sep1[0].toString());;
				listIformacionPrestamos.setModel(new AbstractListModel() {
					public int getSize() {
						return values .length;
					}
					public Object getElementAt(int index) {
						return values [index];
					}
				});	
				
				
			}
		});
		listMostrarPrestamos.setFont(new Font("Arial", Font.PLAIN, 20));
		scrollPane_3.setViewportView(listMostrarPrestamos);
		
		JLabel lblInformacion = new JLabel("Informacion");
		lblInformacion.setFont(new Font("Arial", Font.PLAIN, 20));
		lblInformacion.setBounds(573, 417, 129, 44);
		Prestamos.add(lblInformacion);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(573, 459, 543, 115);
		Prestamos.add(scrollPane_4);
		
		listIformacionPrestamos = new JList();
		listIformacionPrestamos.setFont(new Font("Arial", Font.PLAIN, 20));
		scrollPane_4.setViewportView(listIformacionPrestamos);
		
		JLabel lblLibros_1 = new JLabel("Libros:");
		lblLibros_1.setBounds(573, 589, 51, 16);
		Prestamos.add(lblLibros_1);
		
		JLabel lblRevistas_1 = new JLabel("Revistas:");
		lblRevistas_1.setBounds(573, 617, 65, 16);
		Prestamos.add(lblRevistas_1);
		
		JLabel lblArticulos_1 = new JLabel("Articulos:");
		lblArticulos_1.setBounds(573, 645, 73, 16);
		Prestamos.add(lblArticulos_1);
		
		lblLibrosPrestamos = new JLabel("");
		lblLibrosPrestamos.setBounds(628, 590, 74, 16);
		Prestamos.add(lblLibrosPrestamos);
		
		lblRevistasPrestamos = new JLabel("");
		lblRevistasPrestamos.setBounds(638, 617, 64, 16);
		Prestamos.add(lblRevistasPrestamos);
		
		lblArticulosPrestamos = new JLabel("");
		lblArticulosPrestamos.setBounds(648, 645, 67, 16);
		Prestamos.add(lblArticulosPrestamos);
		
		cbCambiar = new JComboBox();
		cbCambiar.setModel(new DefaultComboBoxModel(new String[] {"Fecha de Entrega", "Entrega"}));
		cbCambiar.setBounds(79, 581, 163, 35);
		Prestamos.add(cbCambiar);
		
		lblCambiar = new JLabel("Cambiar:");
		lblCambiar.setBounds(16, 589, 65, 16);
		Prestamos.add(lblCambiar);
		
		btnAbilitar = new JButton("Abilitar ");
		btnAbilitar.setBackground(Color.CYAN);
		btnAbilitar.setBounds(238, 584, 117, 29);
		Prestamos.add(btnAbilitar);
		btnAbilitar.addActionListener(oyente);
		
		lblFechaEntrega = new JLabel("Fecha Entrega:");
		lblFechaEntrega.setBounds(7, 645, 106, 16);
		Prestamos.add(lblFechaEntrega);
		
		diaPP = new JComboBox();
		diaPP.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30"}));
		diaPP.setBounds(107, 643, 65, 27);
		Prestamos.add(diaPP);
		diaPP.setEnabled(false);
		
		
		label_9 = new JLabel("Dia");
		label_9.setBounds(122, 628, 31, 16);
		Prestamos.add(label_9);
		
		mesPP = new JComboBox();
		mesPP.setModel(new DefaultComboBoxModel(new String[] {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"}));
		mesPP.setBounds(177, 643, 96, 27);
		Prestamos.add(mesPP);
		mesPP.setEnabled(false);
		
		label_10 = new JLabel("Mes");
		label_10.setBounds(193, 628, 31, 16);
		Prestamos.add(label_10);
		
		anoPP = new JComboBox();
		anoPP.setModel(new DefaultComboBoxModel(new String[] {"2019", "2020", "2021", "2022", "2023", "2024", "2025"}));
		anoPP.setBounds(273, 643, 82, 27);
		Prestamos.add(anoPP);
		anoPP.setEnabled(false);
		
		label_11 = new JLabel("Año");
		label_11.setBounds(299, 628, 31, 16);
		Prestamos.add(label_11);
		
		lblEntrega = new JLabel("Entrega:");
		lblEntrega.setBounds(6, 682, 106, 16);
		Prestamos.add(lblEntrega);
		
		cbEntregaCambio = new JComboBox();
		cbEntregaCambio.setModel(new DefaultComboBoxModel(new String[] {"Entregado", "Sin entregar"}));
		cbEntregaCambio.setBounds(69, 673, 135, 35);
		Prestamos.add(cbEntregaCambio);
		cbEntregaCambio.setEnabled(false);
		
		btnCambiar = new JButton("Cambiar");
		btnCambiar.setBackground(Color.CYAN);
		btnCambiar.setBounds(367, 662, 117, 29);
		Prestamos.add(btnCambiar);
		btnPrestar.addActionListener(oyente);
		btnCambiar.addActionListener(oyente);
		btnCambiar.setEnabled(false);
		
		Documentacion = new JPanel();
		Documentacion.setBackground(Color.WHITE);
		frame.getContentPane().add(Documentacion, "name_17826141147657");
		Documentacion.setLayout(null);
		
		lblDocumentacion = new JLabel("Documentacion");
		lblDocumentacion.setFont(new Font("Arial", Font.PLAIN, 30));
		lblDocumentacion.setBounds(444, 0, 233, 51);
		Documentacion.add(lblDocumentacion);
		
		separator_5 = new JSeparator();
		separator_5.setForeground(Color.BLACK);
		separator_5.setBounds(6, 43, 1133, 12);
		Documentacion.add(separator_5);
		
		btnRegresarDocumentacion = new JButton("Regresar");
		btnRegresarDocumentacion.setBackground(Color.ORANGE);
		btnRegresarDocumentacion.setBounds(6, 17, 117, 29);
		Documentacion.add(btnRegresarDocumentacion);
		
		lblCrearDocumento = new JLabel("Crear Documento");
		lblCrearDocumento.setFont(new Font("Arial", Font.PLAIN, 20));
		lblCrearDocumento.setBounds(26, 67, 188, 44);
		Documentacion.add(lblCrearDocumento);
		
		cbTipo = new JComboBox();
		cbTipo.setModel(new DefaultComboBoxModel(new String[] {"Libro", "Revista", "Articulo"}));
		cbTipo.setBounds(65, 154, 106, 35);
		Documentacion.add(cbTipo);
		
		lblTipo = new JLabel("Tipo:");
		lblTipo.setBounds(26, 162, 42, 16);
		Documentacion.add(lblTipo);
		
		lblNumeroDeIdentificacion = new JLabel("No. de identificacion:");
		lblNumeroDeIdentificacion.setBounds(26, 209, 150, 16);
		Documentacion.add(lblNumeroDeIdentificacion);
		
		txtIdentificacion1 = new JTextField();
		txtIdentificacion1.setBackground(Color.GRAY);
		txtIdentificacion1.setBounds(176, 204, 174, 26);
		Documentacion.add(txtIdentificacion1);
		txtIdentificacion1.setColumns(10);
		
		
		btnMostrar = new JButton("Mostrar");
		btnMostrar.setBackground(Color.CYAN);
		btnMostrar.setBounds(183, 154, 117, 29);
		Documentacion.add(btnMostrar);
		
		lblTitulo = new JLabel("Titulo:");
		lblTitulo.setBounds(36, 248, 54, 16);
		Documentacion.add(lblTitulo);
		
		lblMateria = new JLabel("Materia:");
		lblMateria.setBounds(26, 289, 54, 16);
		Documentacion.add(lblMateria);
		
		lblCantidadDeEjemplares = new JLabel("Cantidad de ejemplares:");
		lblCantidadDeEjemplares.setBounds(26, 325, 161, 16);
		Documentacion.add(lblCantidadDeEjemplares);
		
		lblEstado = new JLabel("Autor:");
		lblEstado.setBounds(36, 367, 54, 16);
		Documentacion.add(lblEstado);
		
		lblEditorial = new JLabel("Editorial:");
		lblEditorial.setBounds(28, 410, 62, 16);
		Documentacion.add(lblEditorial);
		
		txtTitulo = new JTextField();
		txtTitulo.setBackground(Color.GRAY);
		txtTitulo.setColumns(10);
		txtTitulo.setBounds(92, 243, 174, 26);
		Documentacion.add(txtTitulo);
		
		
		lblAno = new JLabel("Año:");
		lblAno.setBounds(45, 448, 35, 16);
		Documentacion.add(lblAno);
		
		lblNumero = new JLabel("Numero:");
		lblNumero.setBounds(26, 488, 62, 16);
		Documentacion.add(lblNumero);
		
		lblArbitro = new JLabel("Arbitro:");
		lblArbitro.setBounds(36, 526, 54, 16);
		Documentacion.add(lblArbitro);
		
		txtMateria = new JTextField();
		txtMateria.setBackground(Color.GRAY);
		txtMateria.setColumns(10);
		txtMateria.setBounds(92, 284, 174, 26);
		Documentacion.add(txtMateria);
		
		
		txtCantEjemplares = new JTextField();
		txtCantEjemplares.setBackground(Color.GRAY);
		txtCantEjemplares.setColumns(10);
		txtCantEjemplares.setBounds(187, 320, 79, 26);
		Documentacion.add(txtCantEjemplares);
		
		
		txtAutor = new JTextField();
		txtAutor.setBackground(Color.GRAY);
		txtAutor.setColumns(10);
		txtAutor.setBounds(92, 362, 174, 26);
		Documentacion.add(txtAutor);
		
		
		txtEditorial = new JTextField();
		txtEditorial.setBackground(Color.GRAY);
		txtEditorial.setColumns(10);
		txtEditorial.setBounds(92, 405, 174, 26);
		Documentacion.add(txtEditorial);
		
		txtNumero = new JTextField();
		txtNumero.setBackground(Color.GRAY);
		txtNumero.setColumns(10);
		txtNumero.setBounds(92, 483, 174, 26);
		Documentacion.add(txtNumero);
		
		txtArbitro = new JTextField();
		txtArbitro.setBackground(Color.GRAY);
		txtArbitro.setColumns(10);
		txtArbitro.setBounds(92, 521, 174, 26);
		Documentacion.add(txtArbitro);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.setBackground(Color.CYAN);
		btnAgregar.setBounds(278, 521, 117, 29);
		Documentacion.add(btnAgregar);
		btnAgregar.addActionListener(oyente);
		
		cbAnos = new JComboBox();
		cbAnos.setBackground(Color.GRAY);
		

		cbAnos.setModel(new DefaultComboBoxModel(biblioteca.generarAnos()));
		cbAnos.setBounds(92, 438, 106, 35);
		Documentacion.add(cbAnos);
		
		lblseActivaranLas = new JLabel("(Se activaran las casillas necesarias para cada tipo de documento)");
		lblseActivaranLas.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		lblseActivaranLas.setBounds(26, 108, 342, 16);
		Documentacion.add(lblseActivaranLas);
		
		separator_6 = new JSeparator();
		separator_6.setForeground(Color.BLACK);
		separator_6.setOrientation(SwingConstants.VERTICAL);
		separator_6.setBounds(454, 51, 16, 631);
		Documentacion.add(separator_6);
		
		lblConsultarInformacion = new JLabel("Consultar informacion");
		lblConsultarInformacion.setFont(new Font("Arial", Font.PLAIN, 20));
		lblConsultarInformacion.setBounds(482, 63, 211, 44);
		Documentacion.add(lblConsultarInformacion);
		
		cbConsultaDocumento = new JComboBox();
		cbConsultaDocumento.setModel(new DefaultComboBoxModel(new String[] {"Libro", "Revista", "Articulo"}));
		cbConsultaDocumento.setBounds(482, 120, 106, 35);
		Documentacion.add(cbConsultaDocumento);
		
		btnMostrarDocumento = new JButton("Mostrar");
		btnMostrarDocumento.setBackground(Color.CYAN);
		btnMostrarDocumento.setBounds(600, 123, 117, 29);
		Documentacion.add(btnMostrarDocumento);
		btnMostrarDocumento.addActionListener(oyente);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(482, 178, 616, 185);
		Documentacion.add(scrollPane_1);
		
		listDocumentos = new JList();
		listDocumentos.addListSelectionListener(new ListSelectionListener() {
			@SuppressWarnings("serial")
			public void valueChanged(ListSelectionEvent e) {
				String split = (String) listDocumentos.getSelectedValue();
				String[] sep = split.split(" : ");
				String[] lista = null;
				
				switch (cbConsultaDocumento.getSelectedItem().toString()) {
				
				case "Libro":
					lista = biblioteca.getLibro(sep[1]);
					break;
				case "Revista":
					lista = biblioteca.getRevista(sep[1]);
					break;
				case "Articulo":
					lista = biblioteca.getArticulo(sep[1]);
					break;
				}
				
				String[] values = lista;
				listInformacionDocumento.setModel(new AbstractListModel() {
					public int getSize() {
						return values .length;
					}
					public Object getElementAt(int index) {
						return values [index];
					}
				});	
				
				
				
			}
		});
		listDocumentos.setFont(new Font("Arial", Font.PLAIN, 20));
		scrollPane_1.setViewportView(listDocumentos);
		
		lblInformacionDeDocumento = new JLabel("Informacion de documento");
		lblInformacionDeDocumento.setFont(new Font("Arial", Font.PLAIN, 20));
		lblInformacionDeDocumento.setBounds(482, 378, 265, 44);
		Documentacion.add(lblInformacionDeDocumento);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(482, 430, 612, 200);
		Documentacion.add(scrollPane_2);
		
		listInformacionDocumento = new JList();
		listInformacionDocumento.setFont(new Font("Arial", Font.PLAIN, 20));
		scrollPane_2.setViewportView(listInformacionDocumento);
		
		btnBorrarDocumentos = new JButton("Borrar");
		btnBorrarDocumentos.setBackground(Color.CYAN);
		btnBorrarDocumentos.setBounds(734, 123, 117, 29);
		Documentacion.add(btnBorrarDocumentos);
		
		lblLibros = new JLabel("Libros:");
		lblLibros.setBounds(867, 83, 54, 16);
		Documentacion.add(lblLibros);
		
		lblRevistas = new JLabel("Revistas:");
		lblRevistas.setBounds(867, 107, 69, 16);
		Documentacion.add(lblRevistas);
		
		lblArticulos = new JLabel("Articulos:");
		lblArticulos.setBounds(867, 128, 69, 16);
		Documentacion.add(lblArticulos);
		
		lblCantlibros = new JLabel("");
		lblCantlibros.setBounds(926, 83, 69, 16);
		Documentacion.add(lblCantlibros);
		
		lblCantRevistas = new JLabel("");
		lblCantRevistas.setBounds(938, 107, 69, 16);
		Documentacion.add(lblCantRevistas);
		
		lblCantArticulos = new JLabel("");
		lblCantArticulos.setBounds(938, 128, 69, 16);
		Documentacion.add(lblCantArticulos);
		btnRegresarDocumentacion.addActionListener(oyente);
		btnMostrar.addActionListener(oyente);
		btnBorrarDocumentos.addActionListener(oyente);
		
		
		
		Estadisticas = new JPanel();
		frame.getContentPane().add(Estadisticas, "name_17826149359532");
		Estadisticas.setLayout(null);
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void mostrarClientes() {
		String[] lista = biblioteca.getClientes();
		cbClientes.setModel(new DefaultComboBoxModel(lista));
		cbMostrarClientes.setModel(new DefaultComboBoxModel(lista));
		
	}
	
	private void enabledOff() {
		txtIdentificacion1.setEnabled(false);
		txtTitulo.setEnabled(false);
		txtMateria.setEnabled(false);
		txtCantEjemplares.setEnabled(false);
		txtArbitro.setEnabled(false);
		txtAutor.setEnabled(false);
		txtEditorial.setEnabled(false);
		btnAgregar.setEnabled(false);
		cbAnos.setEnabled(false);
		txtNumero.setEnabled(false);
		
		txtIdentificacion1.setBackground(Color.GRAY);
		txtTitulo.setBackground(Color.GRAY);
		txtMateria.setBackground(Color.GRAY);
		txtCantEjemplares.setBackground(Color.GRAY);
		txtArbitro.setBackground(Color.GRAY);
		txtAutor.setBackground(Color.GRAY);
		txtEditorial.setBackground(Color.GRAY);
		btnAgregar.setBackground(Color.GRAY);
		cbAnos.setBackground(Color.GRAY);
		txtNumero.setBackground(Color.GRAY);
		
		

	}
	
	@SuppressWarnings({ "unchecked", "rawtypes", "serial" })
	private void borrarDocumentacion() {
		txtIdentificacion1.setText(null);
		txtTitulo.setText(null);
		txtMateria.setText(null);
		txtCantEjemplares.setText(null);
		txtArbitro.setText(null);
		txtAutor.setText(null);
		txtEditorial.setText(null);
		txtNumero.setText(null);
		
		String[] values = new String[0];
		try {
			
			listDocumentos.setModel(new AbstractListModel() {
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});	
			}catch(Exception ex) {}
			
			try {
			listInformacionDocumento.setModel(new AbstractListModel() {
				public int getSize() {
					return values.length;
				}
				public Object getElementAt(int index) {
					return values[index];
				}
			});	
			}catch(Exception ex) {}
		
		
	}
	
	
	
	private class MyListener implements ActionListener{

		
		@SuppressWarnings({ "unchecked", "rawtypes", "serial" })
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			

			if (e.getSource() == btnClientes) {
				Clientes.setVisible(true);
				Biblioteca.setVisible(false);
				mostrarClientes();
			}
			
			if (e.getSource() == btnDocumentacion) {
				borrarDocumentacion();
				enabledOff();
				String[][] list = null;
				list = biblioteca.getLibros();
				lblCantlibros.setText(Integer.toString(list[0].length));
				list = biblioteca.getRevistas();
				lblCantRevistas.setText(Integer.toString(list[0].length));
				list = biblioteca.getArticulos();
				lblCantArticulos.setText(Integer.toString(list[0].length));
				Documentacion.setVisible(true);
				Biblioteca.setVisible(false);
			}
			
			if (e.getSource() == btnSalir) {
				biblioteca.guardarDatos();
				System.exit(0);
				
			}
			
			if (e.getSource() == btnPrestamos) {
				String[] lista = biblioteca.getClientes();
				cbClientesPrestamo.setModel(new DefaultComboBoxModel(lista));
				cbClientesPrestamosConsultar.setModel(new DefaultComboBoxModel(lista));
				cbClientesPrestamo1.setModel(new DefaultComboBoxModel(lista));
				cbEntregaCambio.setEnabled(false);
				diaPP.setEnabled(false);
				mesPP.setEnabled(false);
				anoPP.setEnabled(false);
				btnCambiar.setEnabled(false);
				
				
				Prestamos.setVisible(true);
				Biblioteca.setVisible(false);
			}
			
			if (e.getSource() == btnRegresarPrestamos) {
				Prestamos.setVisible(false);
				Biblioteca.setVisible(true);
				
			}
			
			
			if (e.getSource() == btnEstadisticas) {
				Estadisticas.setVisible(true);
				Biblioteca.setVisible(false);
			}
			
			if (e.getSource() == btnRegresarClientes) {
				Clientes.setVisible(false);
				Biblioteca.setVisible(true);
				txtIdentificacion.setText(null);
				txtNombre.setText(null);
				txtDireccion.setText(null);
				String[] values = new String[0];
				listClientes.setModel(new AbstractListModel() {
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});
			}
			
			if (e.getSource() == btnCrear) {
				boolean[] aprobacion = {txtIdentificacion.getText().isEmpty() , txtNombre.getText().isEmpty() , txtDireccion.getText().isEmpty()};
				
				if (aprobacion[0] == false && aprobacion[1] == false && aprobacion[2] == false) {
					try {
						biblioteca.setcliente(Long.parseLong(txtIdentificacion.getText()), txtNombre.getText(),txtDireccion.getText());
						txtIdentificacion.setText(null);
						txtNombre.setText(null);
						txtDireccion.setText(null);
						mostrarClientes();
						}catch (NumberFormatException ex) {
							JOptionPane.showMessageDialog(null,"Ha ingresado una letra en el No.identificacion");
							txtIdentificacion.setText(null);
						}
				}else {
					JOptionPane.showMessageDialog(null,"Hay casillas vacias");
				}
				
				
				
			}
			

			if (e.getSource() == btnEliminar) {
				boolean resp = false;
				
				String nom = cbClientes.getSelectedItem().toString();
				
				try {
				resp = biblioteca.eliminarCliente(nom);
				
				}catch (Exception ex) {}
				
				if (resp == true) {
					JOptionPane.showMessageDialog(null,"Cliente se elimino correctamente");
				} 
				mostrarClientes();
				
			}
			
			
			
			if (e.getSource() == btnMostrarClientes) {
				try {
				String[] values = biblioteca.getCliente(cbMostrarClientes.getSelectedItem().toString());
				
				listClientes.setModel(new AbstractListModel() {
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});	
				}catch(Exception ex) {}
			}
			
			
			if (e.getSource() == btnBorrar) {
				String[] values = new String[0];
				listClientes.setModel(new AbstractListModel() {
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});	
			}
			
			if (e.getSource() == btnRegresarDocumentacion) {
				Documentacion.setVisible(false);
				Biblioteca.setVisible(true);
				
			}
			
			
			if (e.getSource() == btnMostrar) {
				
				txtIdentificacion1.setEnabled(true);
				txtTitulo.setEnabled(true);
				txtMateria.setEnabled(true);
				txtCantEjemplares.setEnabled(true);
				btnAgregar.setEnabled(true);
				txtIdentificacion1.setBackground(Color.WHITE);
				txtTitulo.setBackground(Color.WHITE);
				txtMateria.setBackground(Color.WHITE);
				txtCantEjemplares.setBackground(Color.WHITE);
				btnAgregar.setBackground(Color.WHITE);
				
				switch(cbTipo.getSelectedItem().toString()){
					
				case "Libro":
					txtAutor.setEnabled(true);
					txtEditorial.setEnabled(true);
					txtAutor.setBackground(Color.WHITE);
					txtEditorial.setBackground(Color.WHITE);
					cbAnos.setEnabled(false);
					txtNumero.setEnabled(false);
					txtArbitro.setEnabled(false);
					cbAnos.setBackground(Color.GRAY);
					txtNumero.setBackground(Color.GRAY);
					txtArbitro.setBackground(Color.GRAY);
					break;
				
				case "Revista":
					cbAnos.setEnabled(true);
					txtNumero.setEnabled(true);
					cbAnos.setBackground(Color.WHITE);
					txtNumero.setBackground(Color.WHITE);
					txtAutor.setEnabled(false);
					txtEditorial.setEnabled(false);
					txtArbitro.setEnabled(false);
					txtAutor.setBackground(Color.GRAY);
					txtEditorial.setBackground(Color.GRAY);
					txtArbitro.setBackground(Color.GRAY);
					break;
					
				case "Articulo":
					txtAutor.setEnabled(true);
					txtArbitro.setEnabled(true);
					txtAutor.setBackground(Color.WHITE);
					txtArbitro.setBackground(Color.WHITE);
					txtEditorial.setEnabled(false);
					cbAnos.setEnabled(false);
					txtNumero.setEnabled(false);
					txtEditorial.setBackground(Color.GRAY);
					cbAnos.setBackground(Color.GRAY);
					txtNumero.setBackground(Color.GRAY);
					break;	
				}
			}
			
			
			if (e.getSource() == btnAgregar) {
				
				boolean estado = false;
				boolean paso = false;
				boolean paso2 = false;
				
				
				try {
					Integer.parseInt(txtIdentificacion1.getText());
					paso = true;
				}catch(Exception ex) {JOptionPane.showMessageDialog(null,"Ha ingresado un No. identificacion no valido");txtIdentificacion1.setText(null);}
				
				try {
					Integer.parseInt(txtCantEjemplares.getText());
					paso2 = true;
				}catch(Exception ex) {JOptionPane.showMessageDialog(null,"Ha ingresado una cantidad de ejemplares no valida");txtCantEjemplares.setText(null);}
				
				
				if (paso == true && paso2 == true) {
				
					if (Integer.parseInt(txtCantEjemplares.getText())>0) {
						estado = true;
					} 
				
					switch(cbTipo.getSelectedItem().toString()) {
				
					case "Libro":
					
						boolean[] b = {txtAutor.getText().isEmpty(), txtEditorial.getText().isEmpty(), txtIdentificacion1.getText().isEmpty(), txtTitulo.getText().isEmpty(), txtMateria.getText().isEmpty(), txtCantEjemplares.getText().isEmpty()};
						
						if (b[0] == false && b[1] == false && b[2] == false && b[3] == false  && b[4] == false && b[5] == false ) {
						biblioteca.setLibro(txtAutor.getText(), txtEditorial.getText(), Integer.parseInt(txtIdentificacion1.getText()), txtTitulo.getText(), txtMateria.getText(), Integer.parseInt(txtCantEjemplares.getText()), estado);
						JOptionPane.showMessageDialog(null,"Documento se agrego con exito");
						borrarDocumentacion();
						enabledOff();
						}else {
							JOptionPane.showMessageDialog(null,"Tiene casillas vacias");
						}
						break;
	
					case "Revista":
					
						try {
							Integer.parseInt(cbAnos.getSelectedItem().toString());
						}catch(Exception ex) {JOptionPane.showMessageDialog(null,"Ha dejado el año en blanco");}
					
						try {
							Integer.parseInt(txtNumero.getText());
						}catch(Exception ex) {JOptionPane.showMessageDialog(null,"Ha ingresado un numero de revista no valido");txtNumero.setText(null);}
					
						boolean[] a = {cbAnos.getSelectedItem().toString().isEmpty(), txtNumero.getText().isEmpty(), txtIdentificacion1.getText().isEmpty(), txtTitulo.getText().isEmpty(),txtMateria.getText().isEmpty(), txtCantEjemplares.getText().isEmpty()};
						
						if(a[0] == false && a[1] == false && a[2] == false && a[3] == false && a[4] == false && a[5] == false) {
						biblioteca.setRevista(Integer.parseInt(cbAnos.getSelectedItem().toString()), Integer.parseInt(txtNumero.getText()), Integer.parseInt(txtIdentificacion1.getText()), txtTitulo.getText(),txtMateria.getText(), Integer.parseInt(txtCantEjemplares.getText()), estado);
						borrarDocumentacion();
						enabledOff();
						JOptionPane.showMessageDialog(null,"Documento se agrego con exito");
						}else {
							JOptionPane.showMessageDialog(null,"Tiene casillas vacias");
						}
						
						break;
						
					case "Articulo":
						boolean[] c = {txtArbitro.getText().isEmpty(), txtAutor.getText().isEmpty(), txtIdentificacion1.getText().isEmpty(), txtTitulo.getText().isEmpty(), txtMateria.getText().isEmpty(), txtCantEjemplares.getText().isEmpty()};
						
						if (c[0] == false && c[1] == false && c[2] == false && c[3] == false && c[4] == false && c[5] == false) {
						biblioteca.setArticulo(txtArbitro.getText(), txtAutor.getText(), Integer.parseInt(txtIdentificacion1.getText()), txtTitulo.getText(), txtMateria.getText(), Integer.parseInt(txtCantEjemplares.getText()), estado);
						JOptionPane.showMessageDialog(null,"Documento se agrego con exito");
						borrarDocumentacion();
						enabledOff();
						}else {
							JOptionPane.showMessageDialog(null,"Tiene casillas vacias");
						}

						break;
					}

					
				}

				String[][] list = null;
				list = biblioteca.getLibros();
				lblCantlibros.setText(Integer.toString(list[0].length));
				list = biblioteca.getRevistas();
				lblCantRevistas.setText(Integer.toString(list[0].length));
				list = biblioteca.getArticulos();
				lblCantArticulos.setText(Integer.toString(list[0].length));
				
			}
			
			
			
			if (e.getSource() == btnMostrarDocumento) {
				
				try {
					String[][] documentos = null;
					
					switch (cbConsultaDocumento.getSelectedItem().toString()) {
					
					case "Libro":
						documentos = biblioteca.getLibros();
						break;
					case "Revista":
						documentos = biblioteca.getRevistas();
						break;
					case "Articulo":
						documentos = biblioteca.getArticulos();
						break;
					}
					
					String [][] values = documentos;
					
					listDocumentos.setModel(new AbstractListModel() {
						public int getSize() {
							return values[0] .length;
						}
						public Object getElementAt(int index) {
							return values[0] [index];
						}
					});	
					}catch(Exception ex) {}
				
				
			}
			
			if (e.getSource() == btnBorrarDocumentos) {
				
				String[] values = new String[0];
				
				try {
				
				listDocumentos.setModel(new AbstractListModel() {
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});	
				}catch(Exception ex) {}
				
				try {
				listInformacionDocumento.setModel(new AbstractListModel() {
					public int getSize() {
						return values.length;
					}
					public Object getElementAt(int index) {
						return values[index];
					}
				});	
				}catch(Exception ex) {}

			}
			
			
			if (e.getSource() == btnMostrarPrestamos) {
				String[][] lista = null;
				
				switch(cbTipoPrestamo.getSelectedItem().toString()) {
				
				case "Libro":
					lista = biblioteca.getLibros();
					cbClientesPrestamos.setModel(new DefaultComboBoxModel(lista[1]));
					break;
				case "Revista":
					lista = biblioteca.getRevistas();
					cbClientesPrestamos.setModel(new DefaultComboBoxModel(lista[1]));
					break;
				case "Articulo":
					lista = biblioteca.getArticulos();
					cbClientesPrestamos.setModel(new DefaultComboBoxModel(lista[1]));
					break;
				}
	
			}
			
			if (e.getSource() == btnPrestar) {
				
				String fechaSolicitud = diaP.getSelectedItem().toString() + "/" + mesP.getSelectedItem().toString() + "/" + anoP.getSelectedItem().toString();
				String fechaDevolucion = diaD.getSelectedItem().toString() + "/" + mesD.getSelectedItem().toString() + "/" + anoD.getSelectedItem().toString();
				
				String resultado = biblioteca.setPrestamo(cbClientesPrestamo.getSelectedItem().toString(),cbTipoPrestamo.getSelectedItem().toString() , cbClientesPrestamos.getSelectedItem().toString(), fechaSolicitud, fechaDevolucion);
				
				switch (resultado) {
				
				case "No hay existencias":
					JOptionPane.showMessageDialog(null,"No hay existencias");
					break;
					
				case "El cliente ya tiene 5 prestamos":
					JOptionPane.showMessageDialog(null,"El cliente ya tiene 5 prestamos activos");
					break;
				case "Se agrego el prestamo con exito":
					JOptionPane.showMessageDialog(null,"Se agrego el prestamo con exito");
					break;
				}
			}
			
			if (e.getSource() == btnMostrarPrestamos1) {
				
				ArrayList<String> values = biblioteca.getNombresTipos(cbClientesPrestamo1.getSelectedItem().toString(), cbTipoPrestamo1.getSelectedItem().toString());
				
				String[] val = new String[values.size()];
				
				for (int i = 0; i<= values.size() - 1; i++ ) {
					val[i] = values.get(i);
				}
				
				switch(cbTipoPrestamo1.getSelectedItem().toString()) {
				
				case "Libro":
					cbClientesPrestamos1.setModel(new DefaultComboBoxModel(val));
					break;
				case "Revista":
					cbClientesPrestamos1.setModel(new DefaultComboBoxModel(val));
					break;
				case "Articulo":
					cbClientesPrestamos1.setModel(new DefaultComboBoxModel(val));
					break;
				}
	
			}
			
			
			if (e.getSource() == btnConsultarCliente) {
				
				String[] info = biblioteca.getCantPrestamosCliente(cbClientesPrestamosConsultar.getSelectedItem().toString());
				lblPestamosActivos.setText(info[0]);
				lblPrestamosInactivos.setText(info[1]);
				
					String[] values = biblioteca.getPrestamo(cbClientesPrestamosConsultar.getSelectedItem().toString());
					try {
					listMostrarPrestamos.setModel(new AbstractListModel() {
						public int getSize() {
							return values.length;
						}
						public Object getElementAt(int index) {
							return values[index];
						}
					});	
					}catch(Exception ex) {}
					
					String[] cantTipos = biblioteca.getCantTiposCliente(cbClientesPrestamosConsultar.getSelectedItem().toString());
					lblLibrosPrestamos.setText(cantTipos[0]);
					lblRevistasPrestamos.setText(cantTipos[1]);
					lblArticulosPrestamos.setText(cantTipos[2]);
					
			}
			
			if (e.getSource() == btnAbilitar) {
				btnCambiar.setEnabled(true);
				
				switch(cbCambiar.getSelectedItem().toString()) {
				
				case "Fecha de Entrega":
					diaPP.setEnabled(true);
					mesPP.setEnabled(true);
					anoPP.setEnabled(true);
					cbEntregaCambio.setEnabled(false);
					break;
				case "Entrega":
					cbEntregaCambio.setEnabled(true);
					diaPP.setEnabled(false);
					mesPP.setEnabled(false);
					anoPP.setEnabled(false);
					break;	
				}
			}
			
			if (e.getSource() == btnCambiar) {
				btnCambiar.setEnabled(true);
				
				switch(cbCambiar.getSelectedItem().toString()) {
				
				case "Fecha de Entrega":
					String valor = diaPP.getSelectedItem().toString() + "/" + mesPP.getSelectedItem().toString() + "/" + anoPP.getSelectedItem().toString();
					biblioteca.modificarPrestamo(cbClientesPrestamo1.getSelectedItem().toString(), cbTipoPrestamo1.getSelectedItem().toString(), cbClientesPrestamos1.getSelectedItem().toString(), "Fecha de Entrega", valor);
					break;
				case "Entrega":
					biblioteca.modificarPrestamo(cbClientesPrestamo1.getSelectedItem().toString(), cbTipoPrestamo1.getSelectedItem().toString(), cbClientesPrestamos1.getSelectedItem().toString(), "Entrega", cbEntregaCambio.getSelectedItem().toString());
					break;	
				}
				
				JOptionPane.showMessageDialog(null,"Se cambio el prestamo con exito");
				diaPP.setEnabled(false);
				mesPP.setEnabled(false);
				anoPP.setEnabled(false);
				cbEntregaCambio.setEnabled(false);
				btnCambiar.setEnabled(false);
				
				cbClientesPrestamos1.setModel(new DefaultComboBoxModel(new String[] {}));
				
				
			}
			
			
			
			
			
			
			
			
		}


		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
