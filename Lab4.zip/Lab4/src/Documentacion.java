
public class Documentacion {
	
	protected int numIdentificacion;
	protected String titulo;
	protected String materia;
	protected int cantidadEjemplares;
	protected boolean estado;
	
	
	
	public Documentacion() {
		numIdentificacion = 0;
		titulo = "";
		materia = "";
		cantidadEjemplares = 0;
		estado = false;
	}



	public Documentacion(int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		this.numIdentificacion = numIdentificacion;
		this.titulo = titulo;
		this.materia = materia;
		this.cantidadEjemplares = cantidadEjemplares;
		this.estado = estado;
	}



	/**
	 * @return the numIdentificacion
	 */
	public int getNumIdentificacion() {
		return numIdentificacion;
	}



	/**
	 * @param numIdentificacion the numIdentificacion to set
	 */
	public void setNumIdentificacion(int numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}



	/**
	 * @return the titulo
	 */
	public String getTitulo() {
		return titulo;
	}



	/**
	 * @param titulo the titulo to set
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}



	/**
	 * @return the materia
	 */
	public String getMateria() {
		return materia;
	}



	/**
	 * @param materia the materia to set
	 */
	public void setMateria(String materia) {
		this.materia = materia;
	}



	/**
	 * @return the cantidadEjemplares
	 */
	public int getCantidadEjemplares() {
		return cantidadEjemplares;
	}



	/**
	 * @param cantidadEjemplares the cantidadEjemplares to set
	 */
	public void setCantidadEjemplares(int cantidadEjemplares) {
		this.cantidadEjemplares = cantidadEjemplares;
	}



	/**
	 * @return the estado
	 */
	public boolean getEstado() {
		return estado;
	}



	/**
	 * @param estado the estado to set
	 */
	public void setEstado(boolean estado) {
		this.estado = estado;
	}


	public String toString() {
		
		String estado = "";
		
		if (this.estado == true) {
			estado = "si";
		}else if (this.estado == false) {
			estado = "no";
		}
		
		String retorno = Integer.toString(numIdentificacion) +titulo +materia +Integer.toString(cantidadEjemplares) + estado;
		return retorno;
	}
	

	
	

}
