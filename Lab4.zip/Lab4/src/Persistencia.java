import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Persistencia {
	

	/**
	 * Metodo para guardar los libros en el txt
	 * @param libros
	 */
	public void guardarLibros(ArrayList<Libro> libros) {
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
		
		try {
			f = new File("libros.txt");
			w = new FileWriter(f);
			bw = new BufferedWriter(w);
			wr = new PrintWriter(bw);
			
			
			wr.write("");
			
			for (int i = 0; i<= libros.size() - 1; i++) {
				wr.append(libros.get(i).getAutor() + "@" + libros.get(i).getEditorial() + "@" + libros.get(i).getNumIdentificacion() + "@" + libros.get(i).getTitulo() + "@" + libros.get(i).getMateria() + "@" + libros.get(i).getCantidadEjemplares()+
						"@" + libros.get(i).getEstado()+"\n");
			}
			
			
			
			wr.close();
			bw.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
		}
		

	}
	
	
	
	/**
	 * Metodo para guardar las revistas en el txt
	 * @param revistas
	 */
	public void guardarRevistas(ArrayList<Revista> revistas) {
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
		

	try {
		f = new File("revistas.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("");
		
		for (int i = 0; i<= revistas.size() - 1; i++) {
			wr.append(revistas.get(i).getAno() + "@" + revistas.get(i).getNumero() + "@" + revistas.get(i).getNumIdentificacion() + "@" +
		revistas.get(i).getTitulo() + "@" + revistas.get(i).getMateria() + "@" + revistas.get(i).getCantidadEjemplares() + "@" + revistas.get(i).getEstado()+"\n");
		}
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}
	}
	
	
	
	/**
	 * MEtodo para guardar los articulos en el txt
	 * @param articulos
	 */
	public void guardarArticulos(ArrayList<Articulo> articulos) {
	
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
	
	try {
		f = new File("articulos.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("");
		
		
		for (int i = 0; i<= articulos.size() - 1; i++) {
			wr.append(articulos.get(i).getArbitro() + "@" + articulos.get(i).getAutor() + "@" + articulos.get(i).getNumIdentificacion() + "@" +
		articulos.get(i).getTitulo() + "@" + articulos.get(i).getMateria() + "@" + articulos.get(i).getCantidadEjemplares() + "@" + articulos.get(i).getEstado()+"\n");
		}
		
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}

	
	}
	

	/**
	 * Funcion para pedir los libros guardados
	 * @return
	 */
	@SuppressWarnings("resource")
	public ArrayList<Libro> getLibros(){
		
		File archivo;
		FileReader fr;
		BufferedReader br;
		
		ArrayList<Libro> informacion = new ArrayList<Libro>();
		try {
			
			archivo = new File("libros.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			ArrayList<String> recopilado = new ArrayList<String>();
			String linea;
			
			while((linea = br.readLine()) != null) {
				
				recopilado.add(linea);
			}
			
			int cc = recopilado.size();
			
			if (cc == 0) {
				return new ArrayList<Libro>();
			}else if (cc > 0){
				for(int i = 0;i<= cc - 1;i++) {
					String r = recopilado.get(i);
					String[] split = r.split("@");
					informacion.add(new Libro(split[0],split[1],Integer.parseInt(split[2]),split[3],split[4],Integer.parseInt(split[5]),Boolean.parseBoolean(split[6])));
				}
			}
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
		}
		return informacion;
		
	}
	
	/**
	 * Funcion para obtener las revistas guardadas
	 * @return
	 */
	@SuppressWarnings("resource")
	public ArrayList<Revista> getRevista(){
		
		File archivo;
		FileReader fr;
		BufferedReader br;
		
		ArrayList<Revista> informacion = new ArrayList<Revista>();
		try {
			
			archivo = new File("revistas.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			ArrayList<String> recopilado = new ArrayList<String>();
			String linea;
			
			while((linea = br.readLine()) != null) {
				
				recopilado.add(linea);
			}
			
			int cc = recopilado.size();
			
			if (cc == 0) {
				return new ArrayList<Revista>();
			}else if (cc > 0){
				for(int i = 0;i<= cc - 1;i++) {
					String r = recopilado.get(i);
					String[] split = r.split("@");	
					informacion.add(new Revista(Integer.parseInt(split[0]),Integer.parseInt(split[1]),Integer.parseInt(split[2]),split[3],split[4],Integer.parseInt(split[5]),Boolean.parseBoolean(split[6])));
				}
			}
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
		}
		return informacion;
		
	}
	
	/**
	 * Funcion para obtener los articulos guardados
	 * @return
	 */
	@SuppressWarnings("resource")
	public ArrayList<Articulo> getArticulo(){
			
			File archivo;
			FileReader fr;
			BufferedReader br;
			
			ArrayList<Articulo> informacion = new ArrayList<Articulo>();
			try {
				
				archivo = new File("articulos.txt");
				fr = new FileReader(archivo);
				br = new BufferedReader(fr);
				
				ArrayList<String> recopilado = new ArrayList<String>();
				String linea;
				
				while((linea = br.readLine()) != null) {
					
					recopilado.add(linea);
				}
				
				int cc = recopilado.size();
				
				if (cc == 0) {
					return new ArrayList<Articulo>();
				}else if (cc > 0){
					for(int i = 0;i<= cc - 1;i++) {
						String r = recopilado.get(i);
						String[] split = r.split("@");
						informacion.add(new Articulo(split[0],split[1],Integer.parseInt(split[2]),split[3],split[4],Integer.parseInt(split[5]),Boolean.parseBoolean(split[6])));
					}
				}
				
				br.close();
				fr.close();
				
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
			}
			return informacion;
			
		}
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * funcion para guardar los clientes
	 * @param articulos
	 */
	public void guardarClientes(ArrayList<Cliente> clientes) {
		
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
	
	try {
		f = new File("clientes.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("");
		
		
		for (int i = 0; i<= clientes.size() - 1; i++) {
			wr.append(clientes.get(i).getNumeroIdentificacion() + "@" + clientes.get(i).getNombre() + "@" + clientes.get(i).getDireccion() + "\n");
		}
		
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}

	}
	
	
	/**
	 * funcion para guardar prestamos de cada cliente
	 * @param clientes
	 */
	public void guardarPrestamos( ArrayList<Cliente> clientes) {
		
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
	
	try {
		f = new File("prestamos.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("");
		
		
		for (int i = 0; i<= clientes.size() - 1; i++) {
			ArrayList<Prestamo> prestamos = clientes.get(i).guardarPrestamo();
			String texto = "";
			for (int a = 0; a<= prestamos.size() - 1;a++) {
				texto = texto + prestamos.get(a).getPrestado() + "@" + prestamos.get(a).getNombre() + "@" + prestamos.get(a).getFechaSolicitud() + "@" + prestamos.get(a).getFechaDevolucion() + "@" + prestamos.get(a).getEstado() + "!";
			}
					
			wr.append(clientes.get(i).getNombre()  + "=" + texto +  "\n");
		}
		
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}

	}
	
	/**
	 * funcion para obtener los clientes
	 * @return
	 */
	public ArrayList<Cliente> getClientes(){
		
		File archivo;
		FileReader fr;
		BufferedReader br;
		
		ArrayList<Cliente> informacion = new ArrayList<Cliente>();
		try {
			
			archivo = new File("clientes.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			ArrayList<String> recopilado = new ArrayList<String>();
			String linea;
			
			while((linea = br.readLine()) != null) {
				
				recopilado.add(linea);
			}
			
			int cc = recopilado.size();
			
			if (cc == 0) {
				return new ArrayList<Cliente>();
			}else if (cc > 0){
				for(int i = 0;i<= cc - 1;i++) {
					String r = recopilado.get(i);
					String[] split = r.split("@");
					informacion.add(new Cliente(Long.parseLong(split[0]),split[1],split[2]));
				}
			}
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
		}
		return informacion;
		
	}
	
	
	
	
	/**
	 * funcion para obtener los prestamos
	 * @return
	 */
	public ArrayList<Cliente> getPrestamos(){
		
		File archivo;
		FileReader fr;
		BufferedReader br;
		
		ArrayList<Cliente> clientes = getClientes();
		try {
			
			archivo = new File("prestamos.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			ArrayList<String> recopilado = new ArrayList<String>();
			String linea;
			
			while((linea = br.readLine()) != null) {
				
				recopilado.add(linea);
			}
			
			int cc = recopilado.size();
			
			if (cc > 0) {
				for (int c = 0; c<= clientes.size() - 1;c++) {
					
					for(int i = 0; i<= recopilado.size() - 1;i++) {
						String[] lista = recopilado.get(i).split("=");
						String[] lista1 = lista[1].split("!");
						for(int a = 0; a<= lista1.length - 1;a++) {
						String[] lista2 = lista1[a].split("@");	
						if(lista[0].equals(clientes.get(c).getNombre())) {
							clientes.get(c).setPrestamo(lista2[0], lista2[1], lista2[2], lista2[3], Boolean.parseBoolean((lista2[4])));
						}
						
						}
					
					}
				}
				
			}
			
			
			
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			return clientes;
		}
		return clientes;
		
	}
	
	
	
	
	
	
	
	
}
	
	
	