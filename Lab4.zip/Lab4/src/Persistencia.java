import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Persistencia {
	


	public void guardarLibros(ArrayList<Libro> libros) {
		
		
		
		
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
		
		try {
			f = new File("libros.txt");
			w = new FileWriter(f);
			bw = new BufferedWriter(w);
			wr = new PrintWriter(bw);
			
			
			wr.write("LIBROS");
			
			for (int i = 0; i<= libros.size() - 1; i++) {
				wr.append(libros.get(i).getAutor() + "|" + libros.get(i).getEditorial() + "|" + libros.get(i).getNumIdentificacion() + "|" + libros.get(i).getTitulo() + "|" + libros.get(i).getMateria() + "|" + libros.get(i).getCantidadEjemplares()+
						"|" + libros.get(i).getEstado());
			}
			
			
			
			wr.close();
			bw.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
		}
		

	}
	
	public void guardarRevistas(ArrayList<Revista> revistas) {
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
		

	try {
		f = new File("revistas.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("REVISTAS");
		
		for (int i = 0; i<= revistas.size() - 1; i++) {
			wr.append(revistas.get(i).getAno() + "|" + revistas.get(i).getNumero() + "|" + revistas.get(i).getNumIdentificacion() + "|" +
		revistas.get(i).getTitulo() + "|" + revistas.get(i).getMateria() + "|" + revistas.get(i).getCantidadEjemplares() + "|" + revistas.get(i).getEstado());
		}
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}
	}
	
	public void guardarArticulos(ArrayList<Articulo> articulos) {
	
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
	
	try {
		f = new File("articulos.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("ARTICULOS");
		
		
		for (int i = 0; i<= articulos.size() - 1; i++) {
			wr.append(articulos.get(i).getArbitro() + "|" + articulos.get(i).getAutor() + "|" + articulos.get(i).getNumIdentificacion() + "|" +
		articulos.get(i).getTitulo() + "|" + articulos.get(i).getMateria() + "|" + articulos.get(i).getCantidadEjemplares() + "|" + articulos.get(i).getEstado());
		}
		
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}

	
	}
	
	public void guardarClientes(ArrayList<Cliente> clientes) {
		
		File f;
		FileWriter w;
		BufferedWriter bw;
		PrintWriter wr;
	
	try {
		f = new File("clientes.txt");
		w = new FileWriter(f);
		bw = new BufferedWriter(w);
		wr = new PrintWriter(bw);
		
		wr.write("ARTICULOS");
		
		
		for (int i = 0; i<= clientes.size() - 1; i++) {
			
		}
		
		
		wr.close();
		bw.close();
		
		
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, "Ha sucedido un error " + e);
	}

	
	}
	
	
	
	
	
	
	
	
	
	
	
	public String leerUsu() {
		
		File archivo;
		FileReader fr;
		BufferedReader br;
		String retorno = "";
		try {
			
			archivo = new File("tempUsuario.txt");
			fr = new FileReader(archivo);
			br = new BufferedReader(fr);
			
			String linea;
			
			while((linea = br.readLine()) != null) {
				retorno =linea;
				
			}
			
			br.close();
			fr.close();
			
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ha sucedido un error leyendo el archivo " + e);
		}
		
		return retorno;
	}
	
}
