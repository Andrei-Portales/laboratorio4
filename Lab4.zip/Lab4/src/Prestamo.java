
public class Prestamo {

	private String prestado;
	private String nombre;
	private String fechaSolicitud;
	private String fechaDevolucion;
	private boolean estado;
	
	public Prestamo() {
		prestado = "";
		nombre = "";
		fechaSolicitud = "";
		fechaDevolucion = "";
		estado = false;
	}

	public Prestamo(String prestado, String nombre, String fechaSolicitud, String fechaDevolucion, boolean estado) {
		this.prestado = prestado;
		this.nombre = nombre;
		this.fechaSolicitud = fechaSolicitud;
		this.fechaDevolucion = fechaDevolucion;
		this.estado = estado;
	}

	public String getPrestado() {
		return prestado;
	}

	public void setPrestado(String prestado) {
		this.prestado = prestado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFechaSolicitud() {
		return fechaSolicitud;
	}

	public void setFechaSolicitud(String fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	public String getFechaDevolucion() {
		return fechaDevolucion;
	}

	public void setFechaDevolucion(String fechaDevolucion) {
		this.fechaDevolucion = fechaDevolucion;
	}

	public boolean getEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Prestamo [prestado=" + prestado + ", nombre=" + nombre + ", fechaSolicitud=" + fechaSolicitud
				+ ", fechaDevolucion=" + fechaDevolucion + ", estado=" + estado + "]";
	}
	
	
	
	
	
}
