import java.util.ArrayList;

public class Biblioteca {
	
	private ArrayList<Cliente> clientes;
	private ArrayList<Libro> libros;
	private ArrayList<Revista> revistas;
	private ArrayList<Articulo> articulos;
	Persistencia ppp;
	

	public Biblioteca() {
		ppp = new Persistencia();
		libros = ppp.getLibros();
		revistas = ppp.getRevista();
		articulos = ppp.getArticulo();
		clientes = ppp.getPrestamos();
		
		
	}
	
	/**
	 * Metodo para crear un cliente
	 * @param numeroIdentificacion
	 * @param nombre
	 * @param direccion
	 * @param cantPublicaciones
	 */
	public void setcliente(long numeroIdentificacion,String nombre,String direccion) {
		clientes.add(new Cliente(numeroIdentificacion,nombre,direccion));
	}
	
	/**
	 * Metodo para eliminar un cliente
	 * @param nombre
	 * @return
	 */
	public boolean eliminarCliente(String nombre) {
		
		int cant = clientes.size();
		
		for (int i = 0; i<= cant - 1;i++) {
			String nomb = clientes.get(i).getNombre();

			try {
			if (nombre.equals(nomb)){
				clientes.remove(i);
				return true;
			}
			}catch(Exception e) {
				return false;
			}
			
		}
		return true;
	}
	
	
	/**
	 * Funcion para consultar la informacion de un cliente
	 * @param nombre
	 * @return
	 */
	
	
	public String[] getClientes() {
		
		String[] informacion = new String[clientes.size()];
		
		for(int i = 0; i<= clientes.size() - 1;i++) {
			informacion[i] = clientes.get(i).getNombre();
		}
		return informacion;
		
	}
	
	
	/**
	 * funciona para obtener la infomacion del cliente
	 * @param nombre
	 * @return
	 */
	public String[] getCliente(String nombre) {
		
		String[] informacion = new String[5];
		
		int cant = clientes.size();
		
		for (int i = 0; i<= cant - 1;i++) {
			String nomb = clientes.get(i).getNombre();
			
			if (nombre.equals(nomb)) {
				informacion[0] = "Numero de identificacion: " + clientes.get(i).getNumeroIdentificacion();
				informacion[1] = "Nombre: " + clientes.get(i).getNombre();
				informacion[2] = "Direccion: " + clientes.get(i).getDireccion();
				informacion[3] = "Cantidad de Prestamos: " + clientes.get(i).getCantPrestamos();
			}
		}
		return informacion;
	}
	
	/**
	 * funcion para agregar un libro
	 * @param autor
	 * @param editorial
	 * @param numIdentificacion
	 * @param titulo
	 * @param materia
	 * @param cantidadEjemplares
	 * @param estado
	 */
	public void setLibro(String autor, String editorial,int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		libros.add(new Libro(autor,editorial,numIdentificacion,titulo,materia,cantidadEjemplares,estado));
	}
	
	/**
	 * funcion para agregaruna revista
	 * @param ano
	 * @param numero
	 * @param numIdentificacion
	 * @param titulo
	 * @param materia
	 * @param cantidadEjemplares
	 * @param estado
	 */
	public void setRevista(int ano,int numero,int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		revistas.add(new Revista(ano,numero,numIdentificacion,titulo,materia,cantidadEjemplares,estado));
	}
	
	
	/**
	 * funcion para agregar un articulo
	 * @param arbitro
	 * @param autor
	 * @param numIdentificacion
	 * @param titulo
	 * @param materia
	 * @param cantidadEjemplares
	 * @param estado
	 */
	public void setArticulo(String arbitro, String autor, int numIdentificacion, String titulo, String materia, int cantidadEjemplares, boolean estado) {
		articulos.add(new Articulo(arbitro,autor,numIdentificacion,titulo,materia,cantidadEjemplares,estado));
	}

	
	/**
	 * funcion para obtener la informacion de libros
	 * @return
	 */
	public String[][] getLibros() {
		String[][] informacion = new String[2][libros.size()];
		
		for(int i = 0; i<= libros.size() - 1;i++) {
			informacion[0][i] = libros.get(i).getNumIdentificacion() + " : " + libros.get(i).getTitulo();
		}
		
		for(int i = 0; i<= libros.size() - 1;i++) {
			informacion[1][i] = libros.get(i).getTitulo();
		}
		
		
		return informacion;
	}
	
	/**
	 * funcion para obtener informacion de libros
	 * @return
	 */
	public String[][] getRevistas() {
		String[][] informacion = new String[2][revistas.size()];
		
		for(int i = 0; i<= revistas.size() - 1;i++) {
			informacion[0][i] = revistas.get(i).getNumIdentificacion() + " : " + revistas.get(i).getTitulo();
		}
		
		for(int i = 0; i<= revistas.size() - 1;i++) {
			informacion[1][i] = revistas.get(i).getTitulo();
		}
		
		
		return informacion;
	}
	
	/**
	 * funcion para obtener informacion de articulos
	 * @return
	 */
	public String[][] getArticulos() {
		String[][] informacion = new String[2][articulos.size()];
		
		for(int i = 0; i<= articulos.size() - 1;i++) {
			informacion[0][i] = articulos.get(i).getNumIdentificacion() + " : " + articulos.get(i).getTitulo();
		}
		
		
		for(int i = 0; i<= articulos.size() - 1;i++) {
			informacion[1][i] = articulos.get(i).getTitulo();
		}
		return informacion;
	}
	
	
	/**
	 * funcion para obtenr informacion especifica de libro
	 * @param nombre
	 * @return
	 */
	public String[] getLibro(String nombre) {
		String[] informacion = new String[7];
		int cant = libros.size();
		
		for (int i = 0; i<= cant - 1; i++) {
			
			String nomb = libros.get(i).getTitulo();
			
			if (nombre.equals(nomb)) {
				informacion[0] = "Numero de identificacion: " + libros.get(i).getNumIdentificacion();
				informacion[1] = "Titulo: " + libros.get(i).getTitulo();
				informacion[2] = "Autor: " + libros.get(i).getAutor();
				informacion[3] = "Editorial: " + libros.get(i).getEditorial();
				informacion[4] = "Materia: " + libros.get(i).getMateria();
				informacion[5] = "Cantidad de ejemplares: " + libros.get(i).getCantidadEjemplares();
				
				if (libros.get(i).getEstado() == true) {
					informacion[6] = "Estado: Disponible";
				}else {
					informacion[6] = "Estado: Agotado";
				}
				
			}
			
		}
		
		return informacion;
	}
	
	/**
	 * funcion para obtener informacion de revista
	 * @param nombre
	 * @return
	 */
	public String[] getRevista(String nombre) {
		String[] informacion = new String[7];
		int cant = revistas.size();
		
		for (int i = 0; i<= cant - 1; i++) {
			
			String nomb = revistas.get(i).getTitulo();
			
			if (nombre.equals(nomb)) {
				informacion[0] = "Numero de identificacion: " + revistas.get(i).getNumIdentificacion();
				informacion[1] = "Titulo: " + revistas.get(i).getTitulo();
				informacion[2] = "Año: " + revistas.get(i).getAno();
				informacion[3] = "Numero: " + revistas.get(i).getNumero();
				informacion[4] = "Materia: " + revistas.get(i).getMateria();
				informacion[5] = "Cantidad de ejemplares: " + revistas.get(i).getCantidadEjemplares();
				
				if (revistas.get(i).getEstado() == true) {
					informacion[6] = "Estado: Disponible";
				}else {
					informacion[6] = "Estado: Agotado";
				}
				
				
			}
			
		}
		
		return informacion;
	}
	
	/**
	 * funcion para obtener informacion de articulo
	 * @param nombre
	 * @return
	 */
	public String[] getArticulo(String nombre) {
		
		String[] informacion = new String[7];
		int cant = articulos.size();
		
		for (int i = 0; i<= cant - 1; i++) {
			
			String nomb = articulos.get(i).getTitulo();
			
			if (nombre.equals(nomb)) {
				informacion[0] = "Numero de identificacion: " + articulos.get(i).getNumIdentificacion();
				informacion[1] = "Titulo: " + articulos.get(i).getTitulo();
				informacion[2] = "Autor: " + articulos.get(i).getAutor();
				informacion[3] = "Arbito: " + articulos.get(i).getArbitro();
				informacion[4] = "Materia: " + articulos.get(i).getMateria();
				informacion[5] = "Cantidad de ejemplares: " + articulos.get(i).getCantidadEjemplares();
				
				if (articulos.get(i).getEstado() == true) {
					informacion[6] = "Estado: Disponible";
				}else {
					informacion[6] = "Estado: Agotado";
				}
				
			}
	}
		return informacion;
	}
	
	/**
	 * funcion para crear un prestamo
	 * @param nombreCliente
	 * @param tipo
	 * @param titulo
	 * @param fechaSolicitud
	 * @param fechaDevolucion
	 * @return
	 */
	public String setPrestamo(String nombreCliente,String tipo, String titulo, String fechaSolicitud, String fechaDevolucion) {
		int cant = clientes.size();
		
		switch(tipo) {
		
		case "Libro":
			for (int a = 0; a<= libros.size() - 1; a++) {
				String nom = libros.get(a).getTitulo();
				
				if (titulo.equals(nom)) {
				
					int cantidad = libros.get(a).getCantidadEjemplares();
				
					if (cantidad == 0) {
						return "No hay existencias";
					}else if (cantidad > 0) {
						for (int i = 0; i<= cant - 1; i++) {
							String nomb = clientes.get(i).getNombre();
						
							if (nombreCliente.equals(nomb)) {
								boolean resp = clientes.get(i).setPrestamo(tipo, titulo, fechaSolicitud, fechaDevolucion, false);
							
								if (resp == false) {
									return "El cliente ya tiene 5 prestamos";
								}
								if (resp == true) {
									
									libros.get(a).setCantidadEjemplares(libros.get(a).getCantidadEjemplares() - 1);
									if (libros.get(a).getCantidadEjemplares()== 0) {
										libros.get(a).setEstado(false);
									}
								}
							}
						}
					}
				}
			}
			break;
			
		case "Revista":
			for (int a = 0; a<= revistas.size() - 1; a++) {
				String nom = revistas.get(a).getTitulo();
				
				if (titulo.equals(nom)) {
				
					int cantidad = revistas.get(a).getCantidadEjemplares();
				
					if (cantidad == 0) {
						return "No hay existencias";
					}else if (cantidad > 0) {
						for (int i = 0; i<= cant - 1; i++) {
							String nomb = clientes.get(i).getNombre();
						
							if (nombreCliente.equals(nomb)) {
								boolean resp = clientes.get(i).setPrestamo(tipo, titulo, fechaSolicitud, fechaDevolucion, false);
							
								if (resp == false) {
									return "El cliente ya tiene 5 prestamos";
								}
								if (resp == true) {
									
									revistas.get(a).setCantidadEjemplares(revistas.get(a).getCantidadEjemplares() - 1);

									if (revistas.get(a).getCantidadEjemplares()== 0) {
										revistas.get(a).setEstado(false);
									}
								}
							}
						}
					}
				}
			}
			break;
			
		case "Articulo":
			for (int a = 0; a<= articulos.size() - 1; a++) {
				String nom = articulos.get(a).getTitulo();
				
				if (titulo.equals(nom)) {
				
					int cantidad = articulos.get(a).getCantidadEjemplares();
				
					if (cantidad == 0) {
						return "No hay existencias";
					}else if (cantidad > 0) {
						for (int i = 0; i<= cant - 1; i++) {
							String nomb = clientes.get(i).getNombre();
						
							if (nombreCliente.equals(nomb)) {
								boolean resp = clientes.get(i).setPrestamo(tipo, titulo, fechaSolicitud, fechaDevolucion, false);
							
								if (resp == false) {
									return "El cliente ya tiene 5 prestamos";
								}
								if (resp == true) {
									
									articulos.get(a).setCantidadEjemplares(articulos.get(a).getCantidadEjemplares()- 1);
									if (articulos.get(a).getCantidadEjemplares()== 0) {
										articulos.get(a).setEstado(false);
									}
								}
							}
						}
					}
				}
			}

			break;
			
		}

		return "Se agrego el prestamo con exito";
	}
	
	
	
	/**
	 * funcion para obtener informacion de prestamo especifico
	 * @param cliente
	 * @param tipo
	 * @param nombre
	 * @return
	 */
	@SuppressWarnings("null")
	public String[][] getPrestamo(String cliente, String tipo, String nombre){
		
		String[][] informacion = null; 
		
		for (int i = 0; i<= clientes.size() - 1; i++) {
			informacion = new String[2][clientes.get(i).getCantPrestamosTotales()];
			String nomb = clientes.get(i).getNombre();
			
			if (cliente.equals(nomb)) {
				informacion[0] = clientes.get(i).getPrestamosCompletos();
			}
			String[] tipos = clientes.get(i).getCantTipos();
			
			for (int a = 0 ;a <= tipos.length - 1 ;a++) {
				
				informacion[1][a] = tipos[a];
			}
		}
	return informacion;
	}
	
	
	/**
	 * funcion para obtener un prestamo
	 * @param cliente
	 * @return
	 */
	public String[] getPrestamo(String cliente){
		String[] informacion = null; 
		
		for (int i = 0; i<= clientes.size() - 1; i++) {
			String nomb = clientes.get(i).getNombre();
			
			if (cliente.equals(nomb)) {
				informacion= clientes.get(i).getPrestamosCompletos();
			}
		}
			
		return informacion;
		
	}
	
	
		
		
		
	
	/**
	 * funcion para modificar la informacion de prestamo
	 * @param cliente
	 * @param tipo
	 * @param nombre
	 * @param cambio
	 * @param valor
	 * @return
	 */
	public boolean modificarPrestamo(String cliente,String tipo,String nombre,String cambio, String valor) {
		
		for (int i = 0;i <= clientes.size() - 1 ; i++) {
			String client = clientes.get(i).getNombre();
			
			if (cliente.equals(client)) {
				clientes.get(i).modificarPrestamo(tipo, nombre, cambio, valor);		
			}
		}
		
		switch(tipo) {
		
		case "Libro":
			for(int i = 0;i<= libros.size() - 1;i++) {
				String nomb = libros.get(i).getTitulo();
				
				if (nombre.equals(nomb)) {
					int cant = libros.get(i).getCantidadEjemplares();
					cant++;
					libros.get(i).setCantidadEjemplares(cant);
				}
			}
			
			break;
		case "Revista":
			for(int i = 0;i<= revistas.size() - 1;i++) {
				String nomb = revistas.get(i).getTitulo();
				
				if (nombre.equals(nomb)) {
					int cant = revistas.get(i).getCantidadEjemplares();
					cant++;
					revistas.get(i).setCantidadEjemplares(cant);
				}
			}
			
			break;
		case "Articulo":
			for(int i = 0;i<= articulos.size() - 1;i++) {
				String nomb = articulos.get(i).getTitulo();
				
				if (nombre.equals(nomb)) {
					int cant = articulos.get(i).getCantidadEjemplares();
					cant++;
					articulos.get(i).setCantidadEjemplares(cant);
				}
			}
			
			
			break;
			
		}
		
		return true;
	}
	
	
	
	
	/**
	 * funcion para obtener informacion de prestamo
	 * @param cliente
	 * @param tipo
	 * @param nombre
	 * @return
	 */
	public String[] getInformacionPrestamo(String cliente, String tipo, String nombre) {
		String[] informacion = null;
		
		for (int i=0;i<=clientes.size() - 1; i++) {
			String nomb = clientes.get(i).getNombre();
			
			if (cliente.equals(nomb)) {
				informacion = clientes.get(i).getPrestamo(tipo, nombre);
			}
		}
		return informacion;
	}
	
	
	
	
	
	/** 
	 * Funcion que genera años de 1800 a 2019
	 * @return
	 */
	public String[] generarAnos() {
		
		String[] anos = new String[221];
		
		int ano = 1800;
		
		anos[0] = "";
		for (int i = 1;i<= 220;i++) {
			anos[i] = Integer.toString(ano);
			ano++;
		}
		
		return anos;
	}
	
		
	/**
	 * obtener cantidad de prestamos
	 * @param cliente
	 * @return
	 */
	public String[] getCantPrestamosCliente(String cliente) {
		String[] informacion = new String[2];
		
		for (int i = 0; i<= clientes.size() - 1;i++) {
			
			String cli = clientes.get(i).getNombre();
			
			if (cliente.equals(cli)) {
				informacion[0] = Integer.toString(clientes.get(i).getCantPrestamos());
				informacion[1] = Integer.toString(clientes.get(i).getCantPrestamosInactivos());
			}
		}
		return informacion;
	}
		
	/**
	 * obtener infomacion de documentos de cliente
	 * @param cliente
	 * @return
	 */
	public String[] getCantTiposCliente(String cliente) {
		String[] informacion = null;
		
		for(int i = 0; i<= clientes.size() - 1;i++) {
			String nomb = clientes.get(i).getNombre();
			
			if (cliente.equals(nomb)) {
				informacion = clientes.get(i).getCantTipos();
				
			}
			
		}
		
		return informacion;
	}
	
	/**
	 * funcion para obtener el nombre de los documentos que presto el cliente
	 * @param cliente
	 * @param tipo
	 * @return
	 */
	public ArrayList<String> getNombresTipos(String cliente, String tipo){
		ArrayList<String> informacion = null;
		
		for(int i = 0; i<= clientes.size() - 1;i++) {
			String nomb = clientes.get(i).getNombre();
			
			if (cliente.equals(nomb)) {
				informacion = clientes.get(i).getNombresTipos(tipo);
			}
		}
	
		return informacion;
	}
	
	
	public void guardarDatos() {
		ppp.guardarLibros(libros);
		ppp.guardarArticulos(articulos);
		ppp.guardarRevistas(revistas);
		ppp.guardarClientes(clientes);
		ppp.guardarPrestamos(clientes);
	}
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
