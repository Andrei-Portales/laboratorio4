import java.util.ArrayList;

public class Cliente {

	private long numeroIdentificacion;
	private String nombre;
	private String direccion;
	@SuppressWarnings("unused")
	private int cantPrestamos = 0;
	
	private ArrayList<Prestamo> prestamos;
	
	
	/**
	 * Constructor sin parametros
	 */
	public Cliente() {
		numeroIdentificacion = 0;
		nombre = "";
		direccion = "";
		
		prestamos = new ArrayList<Prestamo>();
	}
	
	/**
	 * Constructor con parametros
	 * @param numeroIdentificacion
	 * @param nombre
	 * @param direccion
	 * @param cantPublicaciones
	 */
	public Cliente(long numeroIdentificacion,String nombre,String direccion) {
		this.numeroIdentificacion = numeroIdentificacion;
		this.nombre = nombre;
		this.direccion = direccion;
		
		
		prestamos = new ArrayList<Prestamo>();
	}
	
	
	public ArrayList<String> getNombresTipos(String tipo) {
		ArrayList<String> informacion = new ArrayList<String>();
		
		for (int i = 0;i<= prestamos.size() - 1 ; i++) {
			String tip = prestamos.get(i).getPrestado();
			
			if (tipo.equals(tip) && prestamos.get(i).getEstado() == false) {
				informacion.add(prestamos.get(i).getNombre());
				
				
			}
			
		}
		return informacion;
	}
	
	
	public void modificarPrestamo(String tipo,String nombre, String cambio, String valor) {
		
		for(int i = 0;i<= prestamos.size() -1 ; i++ ) {
			
			if (tipo.equals(prestamos.get(i).getPrestado()) && nombre.equals(prestamos.get(i).getNombre())) {
				switch(cambio) {
				
				
				case "Fecha de Entrega":
					prestamos.get(i).setFechaDevolucion(valor);
					break;
				case "Entrega":
					if (valor.equals("Entregado")) {
						prestamos.get(i).setEstado(true);
					}else if (valor.equals("Sin entregar")) {
						prestamos.get(i).setEstado(false);
					}
					break;
				}
			}
		}
		
		
	}
	
	
	
	

	/**
	 * Funcion para asigar un prestamo a un cliente
	 * @param prestado
	 * @param nombre
	 * @param fechaSolicitud
	 * @param fechaDevolucion
	 * @param estado
	 * @return
	 */
	public boolean setPrestamo(String prestado, String nombre, String fechaSolicitud, String fechaDevolucion, boolean estado){

		if (getCantPrestamos() < 5) {
		prestamos.add(new Prestamo(prestado,nombre,fechaSolicitud,fechaDevolucion,estado));
		
		for (int i = 0; i<= prestamos.size()-1; i++) {
			String tip= prestamos.get(i).getPrestado();
			String nom= prestamos.get(i).getNombre();
			
			if (prestado.equals(tip) && nombre.equals(nom)) {
				
				boolean est = prestamos.get(i).getEstado();
				
				if (est == false) {
					cantPrestamos++;
				}
			}
		}
		
		} else if (getCantPrestamos() == 5){
			return false;
		}
		return true;
	}
	
	
	/**
	 * Funcion para obtener la cantidad de prestamos del cliente
	 * @return
	 */
	public int getCantPrestamos() {
		@SuppressWarnings("unused")
		int cantPrestamos = 0;
		
		for (int i = 0; i<= prestamos.size()-1; i++) {
			boolean est = prestamos.get(i).getEstado();
			if (est == false) {
				cantPrestamos++;
			}
		}
		return cantPrestamos;
	}
	
	
	
	public int getCantPrestamosInactivos() {
		@SuppressWarnings("unused")
		int cantPrestamos = 0;
		
		for (int i = 0; i<= prestamos.size()-1; i++) {
			boolean est = prestamos.get(i).getEstado();
			if (est == true) {
				cantPrestamos++;
			}
		}
		return cantPrestamos;
	}
	
	
	
	
	
	
	
	public int getCantPrestamosTotales() {
		return prestamos.size();
	}
	
	
	public String[] getPrestamosCompletos() {
		String[] informacion = new String[prestamos.size()];
		
		for (int i = 0; i<= prestamos.size()-1;i++) {
			boolean estado = prestamos.get(i).getEstado();
			String sta = "";
			
			if (estado == false) {
				sta = "Sin entregar";
			}else {
				sta = "Entregado";
			}
			
			
			informacion[i] =  prestamos.get(i).getPrestado()+ " : "+ prestamos.get(i).getNombre() + " - "+ sta;
		}
		return informacion;
	}
	
	
	
	public String[] getCantTipos() {
		int c1= 0;
		int c2 = 0;
		int c3 = 0;
		String[] cantidades = new String[3];
		
		for (int i = 0; i<= prestamos.size() -1 ;i++) {
			String p = prestamos.get(i).getPrestado();
			
			if (p.equals("Libro")) {
				c1++;
			}else if (p.equals("Revista")) {
				c2++;
			}else if (p.equals("Articulo")) {
				c3++;
			}
		}
		cantidades[0] = Integer.toString(c1);
		cantidades[1] = Integer.toString(c2);
		cantidades[2] = Integer.toString(c3);
		return cantidades;
	}
	
	
	/**
	 * Funcion para obtener la informacion del prestamo 
	 * @param prestado
	 * @param nombre
	 * @return
	 */
	public String[] getPrestamo(String prestado, String nombre) {
		String[] retorno = new String[5];
		int cantidad = prestamos.size();
		
		for (int i = 0; i<= cantidad - 1; i++) {
			String tipo = prestamos.get(i).getPrestado();
			String nom = prestamos.get(i).getNombre();
			
			if (prestado.equals(tipo) && nombre.equals(nom)) {
				retorno[0] = "Tipo de prestamo: " + prestamos.get(i).getPrestado();
				retorno[1] = "Nombre del objeto: " + prestamos.get(i).getNombre();
				retorno[2] = "Fecha de solicitud: " + prestamos.get(i).getFechaSolicitud();
				retorno[3] = "Fecha de devolucion: " + prestamos.get(i).getFechaDevolucion();
				
				if (prestamos.get(i).getEstado() == true) {
					retorno[4] = "Estado: " + "Entregado";
				}else if(prestamos.get(i).getEstado() == false) {
					retorno[4] = "Estado: " + "Sin Entregar";
				}	
			}
		}
		return retorno;
	}
	
	
	public ArrayList<Prestamo> guardarPrestamo(){
		return prestamos;
	}
	
	

	public long getNumeroIdentificacion() {
		return numeroIdentificacion;
	}

	public void setNumeroIdentificacion(long numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	@Override
	public String toString() {
		return "Cliente [numeroIdentificacion=" + numeroIdentificacion + ", nombre=" + nombre + ", direccion="
				+ direccion ;
	}
	
	
	
	
	
	
}
